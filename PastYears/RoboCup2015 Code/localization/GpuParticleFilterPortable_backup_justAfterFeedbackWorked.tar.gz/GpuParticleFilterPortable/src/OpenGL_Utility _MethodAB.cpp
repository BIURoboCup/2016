/*
 * OpenGL_Utility.cpp
 *
 *  Created on: Jul 15, 2015
 *      Author: darwini5
 */


#include "OpenGL_Utility_MethodAB.hpp"

//#include "opencv2/core/opengl_interop.hpp"
// OpenGL Includes:

//#include <GL/glext.h>



#include <iostream>
#include <fstream>
#include <string>
using namespace std;


#include <stdio.h>
#include <time.h>

int gl_lasterror;
#define GLERROR(x) if ((gl_lasterror=glGetError())) cout << "Error @" << x << ": " <<  gl_lasterror << endl;


/*
 * *************************************************************
 * 				FROM WEBER COURSE - SEMSTER A (CG)
 * *************************************************************
 */

//Macro to make code more readable
#define BUFFER_OFFSET(offset)   ((GLvoid*) (offset))

struct Shader
{
	std::string filename;
	GLenum      type;
	std::string source;
};


std::string readShaderSource(const std::string& shaderFile)
{
	std::ifstream ifile(shaderFile.c_str());
	std::string filetext;

	while(ifile.good())
	{
		std::string line;
		std::getline(ifile, line);
		filetext.append(line + "\n");
	}
	ifile.close();
	return filetext;
}



//create a GLSL program object from vertex and fragment shader files
GLuint initShader(std::string vertexShaderFileName, std::string fragmentShaderFileName)
{
	const int shadersCount = 2;

	Shader shaders[shadersCount] =
	{
		{vertexShaderFileName, GL_VERTEX_SHADER, std::string()},
		{fragmentShaderFileName, GL_FRAGMENT_SHADER, std::string()}
	};

	GLuint program = glCreateProgram();

	for ( int i = 0; i < shadersCount; ++i ) {
		Shader& s = shaders[i];
		s.source = readShaderSource( s.filename );
		if (shaders[i].source.empty())
		{
			std::cout << "Failed to read " << s.filename << std::endl;
			return 0;
		}

		GLuint shader = glCreateShader( s.type );
		const GLchar* strings[1];
		strings[0] = s.source.c_str();
		glShaderSource(shader, 1, strings, NULL);

		glCompileShader( shader );

		GLint  compiled;
		glGetShaderiv( shader, GL_COMPILE_STATUS, &compiled );
		if ( !compiled ) {
			std::cout << s.filename << " failed to compile:" << std::endl;
			GLint  logSize = 0;
			glGetShaderiv(shader, GL_INFO_LOG_LENGTH, &logSize);
			char* logMsg = new char[logSize];
			glGetShaderInfoLog(shader, logSize, NULL, logMsg);
			std::cout << logMsg << std::endl;
			delete [] logMsg;
			return 0;
		}

		glAttachShader(program, shader);
	}

	/* link  and error check */
	glLinkProgram(program);

	GLint  linked;
	glGetProgramiv( program, GL_LINK_STATUS, &linked );
	if ( !linked ) {
		std::cout << "Shader program failed to link" << std::endl;
		GLint  logSize;
		glGetProgramiv( program, GL_INFO_LOG_LENGTH, &logSize);
		char* logMsg = new char[logSize];
		glGetProgramInfoLog( program, logSize, NULL, logMsg );
		std::cout << logMsg << std::endl;
		delete [] logMsg;

		return 0;
		//exit( EXIT_FAILURE );
	}

	/* use program object */
	glUseProgram(program);

	return program;
}


/*
 * *************************************************************
 * 				FROM PROJECT BUILDING - METHOD A - RENDED READING int<->float
 * *************************************************************
 */
// -------------------------- Variables ------------------------
GLuint vbo = 0;
GLuint vao = 0 ;

const int win_width = 800;
const int win_height = 640;

static const float pointsXYZ[] =
	{
			// First triangle:
		    -1.0f,	 -1.0f, 	0.0f,
		    1.0f,	 -1.0f, 	0.0f,
		    -1.0f,	  1.0f, 	0.0f,


			// Second triangle:
		    -1.0f,	  1.0f, 	0.0f,
		    1.0f,	 -1.0f, 	0.0f,
			1.0f,	  1.0f, 	0.0f,

	};

static const GLfloat pointsUV[] =
{
		// First triangle:
	    0.0f,	 0.0f,
	    1.0f,	 0.0f,
	    0.0f,	 1.0f,
		// Second triangle:
	    0.0f,	  1.0f,
	    1.0f,	  0.0f,
		1.0f,	  1.0f,
};

GLuint _textureID;
GLuint _shaderID;

int _gl_Default_Order[1] = {GL_TEXTURE0}; // up to GL_TEXTURE31
unsigned char *raw_image = NULL;

// --------------------- _gl_ Micro Function -------------------

void _gl_Closing() {
	cout << "OpenGL close function called...\n";
}

char ex[win_height][win_width][4];

void _gl_drawToTexture(GLuint texId, GLvoid* pxlData = 0 ) {
	//		----> all future texture functions will modify this texture - The binded!
	// please notice that glBindTexture also used to set the current texture to the
	// active texture (that was set with glActiveTexture, default to texture0)
	glBindTexture(GL_TEXTURE_2D, texId);
	GLERROR("_gl_tex_bind");

	// Give an image (*pxldata =0) for empty
	glTexImage2D(GL_TEXTURE_2D, 0,GL_RGBA, win_width, win_height, 0,GL_RGBA, GL_UNSIGNED_BYTE, pxlData);
	GLERROR("_gl_tex_copy_data");

	// Poor filtering. Needed !
	// ( we chose the fastest method to speed it up)
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);

	glGenerateMipmap(GL_TEXTURE_2D);
	GLERROR("_gl_tex_config");
}


void _gl_Bind2DTexturesToGPU(GLuint* texIDs, int* texOrder, int n) {
	int _info;
	glGetIntegerv(GL_MAX_TEXTURE_IMAGE_UNITS, &_info);
	if (n > _info) {
		cout << "Error occured! you tried to bound " << n << "textures. Max is: " << _info << endl<< flush;
		return;
	}

	for (int i=0;i<n;i++) {
		// Tell gpu what texture 'slot' we want to modify
		// and then bind the texture by giving the correct id that the gpu gave us
		// when we created the texture before on the gpu.

		// This is a process done entirely on the gpu.
		// All data from the cpu must be copied using glTexImage2D
		// or with our own function : "_gl_drawToTexture"

		glActiveTexture(texOrder[i]);
		glBindTexture(GL_TEXTURE_2D, texIDs[i]);
	}
}

void _gl_BindTexturesToShader(GLuint shaderId, std::vector<string> names) {
	// Assumption:
	//		1) glProgram(shaderId) must be used because we change only active shader.
	//		2) this function assume the textures were bound in the range GL_TEXTURE0 - GL_TEXTURE{i}
	//				and the names given are in correct order (first-0, last-i)
	for (unsigned int i = 0; i < names.size() ; i++) {
		int locationInShader = glGetUniformLocation(shaderId, names[i].c_str());
		glUniform1i(locationInShader, i);
	}
}

int counter =0;
// --------------------- _gl_ Draw Function --------------------

// Recomended using layout:
//http://stackoverflow.com/questions/15639957/glgetattriblocation-returns-1-when-retrieving-existing-shader-attribute

enum MyLayout {
		lPosition = 0,
		lUV = 1,
	};

void _gl_Draw()
{

	int err=0;

	glClear(GL_COLOR_BUFFER_BIT);
	glClearColor(1.0f,0.5f,0.27f,1.0f);
	GLERROR("clear_cc");

	glEnableVertexAttribArray(lPosition);
	glEnableVertexAttribArray(lUV);
	GLERROR("draw_enable")

	// Draw the rectangle with 2 traingles 2*3 = 6
	glDrawArrays(GL_TRIANGLES, 0, 6); // Starting from vertex 0:6
	GLERROR(3)

	glDisableVertexAttribArray(lPosition);
	glDisableVertexAttribArray(lUV);
	GLERROR("draw_disable")



	// Read data back from gpu:

	raw_image = new unsigned char[win_height*win_width*4];
	glReadPixels(0, 0, win_width, win_height, GL_RGBA, GL_UNSIGNED_BYTE, raw_image);
	printf("data: (%d,\t %d,\t %d,\t %d) ->  ",raw_image[0],raw_image[1],raw_image[2],raw_image[3]);
	cout << "Data: " << *(float*)raw_image << endl;
	delete [] raw_image;

	//glutSwapBuffers();


}


// ----------------------- Startup Functions --------------------
// We create rectangle from 2 triangles (in normalized values) :

void ex_fill() {

	for (int i=0;i<win_height;i++) {
		for(int j=0;j<win_width;j++){
			*((float*)ex[i][j]) = 1.7f;
		}
	}
}

int _gl_InitThreadData() {
	cout << "_gl_initThreadData" << endl << flush;
	GLERROR("FirstEver")


	glDisable(GL_CULL_FACE);
	GLERROR("cull")


	glGenVertexArrays(1, &vao);
	cout << "VAO:" << (int)vao << endl;
	GLERROR(5)

	glBindVertexArray(vao);
	GLERROR(6)

	// Generate Vertex Buffer Object (VBO)
	// VBO used to store vertex data (position, color, uv ...) in the gpu.
	//		this way we don't need to copy this data every time from the cpu (mainly for large 3d models).
	// Later on we will point variables in the shader to this buffer (with pointers in the gpu).
	glGenBuffers (1, &vbo);	// count=1.
	cout << "VBO:" << (int)vbo << endl;
	GLERROR(7)

	// From now on the active Array Buffer is our vbo.
	glBindBuffer (GL_ARRAY_BUFFER, vbo);
	GLERROR(8)

	// Initialize the `vbo` size for our need we NULL data.
	//		Once created a buffer cannot be resized. (but can be deleted and re-generated)
	glBufferData (GL_ARRAY_BUFFER,  sizeof (pointsXYZ) + sizeof(pointsUV), 0, GL_STATIC_DRAW);

	// Copy our data to the buffer one after another:
	glBufferSubData(GL_ARRAY_BUFFER, 0 , sizeof (pointsXYZ), pointsXYZ);
	glBufferSubData(GL_ARRAY_BUFFER, sizeof (pointsXYZ) , sizeof (pointsUV), pointsUV);
	GLERROR(9)


	/*
	glEnableVertexAttribArray(0);
		//GLERROR(0)

	glBindBuffer(GL_ARRAY_BUFFER, vbo);
	GLERROR(1)

	glVertexAttribPointer(
	   0,                  // attribute 0. No particular reason for 0, but must match the layout in the shader.
	   3,                  // size
	   GL_FLOAT,           // type
	   GL_FALSE,           // normalized?
	   0,                  // stride
	   (void*)0            // array buffer offset
	);
	GLERROR(2)
*/




	// The texture we're going to render to
	glGenTextures(1,		// count of texture (up to 32)
			&_textureID);	// where to store indexes.
	GLERROR("tex_gen")

	// Start with this texture:
	ex_fill();
	_gl_drawToTexture(_textureID,ex);
	GLERROR("tex_fill")

	// Compile and link our shader:
	_shaderID = initShader("Shaders/pvs.glsl","Shaders/pfs.glsl");
	if (!_shaderID)
	{
		cout << "Error occoured while loading the shader..." << endl;
		return 0; // FALSE
	}

	// Tell gpu to choose this shader as active:
	glUseProgram(_shaderID);
	GLERROR("use_shader")

	/*
	glBindBuffer (GL_ARRAY_BUFFER, vbo);
	*/
	// Now that we loaded our shader, we will provide him with all the data he
	//	need.

	// Now give the shader our texture:
	//place = glGetUniformLocation(_shaderID, "tex0");
	//glUniform1i(place, 0); // GL_TEXTURE0 - the default.

	// Remember! our buffer `vbo` is still the active buffer and all
	// 	pointers are pointing at him.
	glEnableVertexAttribArray(lPosition);// Enable it as vertex array
	GLERROR("pos_set")
	glVertexAttribPointer(lPosition,	// Id of attribute in shader
			3,						// Vector element (we use vec3, so 3)
			GL_FLOAT,				// type of data
			GL_FALSE,				// Normalize if not float?
			0,						// stride (= jumping indexes after each element)
			0);						// offset
	GLERROR("pos_point")

	glEnableVertexAttribArray(lUV);
	GLERROR("uv_set")
	glVertexAttribPointer(lUV, 2, GL_FLOAT, GL_FALSE, 0, (GLvoid*)sizeof(pointsXYZ));
	GLERROR("uv_point")


	return 1; // TRUE
}


void *_gl_MainThread(void* arg) {
	// initialize GLUT

	openglInitData *_data = (openglInitData*)arg;
	glewExperimental=GL_TRUE; // For linux since glew has some bugs.
	glutInit(_data->argc, _data->argv);

	// Most important! give us opengl 3.3 context!
	glutInitContextVersion(3, 3);

	glutInitDisplayMode( GLUT_RGBA | GLUT_DOUBLE  | GLUT_DEPTH | GLUT_ALPHA);
	glutInitWindowPosition( 20, 20 );
	glutInitWindowSize( win_width, win_height );

	// Set callbacks for opengl drawing (=rendering results)
	glutDisplayFunc(&_gl_Draw);
	glutIdleFunc(&_gl_Draw);

	// Set the callback function to opengl exisiting.
	glutCloseFunc(&_gl_Closing);


	glutCreateWindow( "openGL Particle-Filter Main window." );

	glewExperimental=GL_TRUE;
	if(glewInit() == GLEW_OK)
	{




		// Make the window black:
		//glViewport(0,0, win_width, win_height);

		glClear(GL_COLOR_BUFFER_BIT);
		glClearColor(0.0f,0.0f,0.0f,1.0f);
		glutSwapBuffers();


		// Get information about this openGL context:
		int _info = 0;

		cout << "GL Version  " << glGetString(GL_VERSION) << endl;
		cout << "GL Shader Version: " << glGetString(GL_SHADING_LANGUAGE_VERSION) << endl << flush;
		cout << "GL Vendor: " << glGetString(GL_VENDOR) << endl << flush;
		cout << "GL Renderer: " << glGetString(GL_RENDERER) << endl << endl << flush;
		glGetIntegerv(GL_MAX_TEXTURE_IMAGE_UNITS, &_info);
		cout << "Maximum textures unit to be bound at once: " << _info << endl << flush;
		glGetIntegerv(GL_MAX_COMBINED_TEXTURE_IMAGE_UNITS, &_info);
		cout << "Maximum textures unit to be bound at once (all programs combined): " << _info << endl << flush;
		glGetIntegerv(GL_MAX_TEXTURE_SIZE, &_info);
		cout << "Maximum textures size: " << _info << endl << flush;

		// Feedback info:
		glGetIntegerv(GL_MAX_TRANSFORM_FEEDBACK_INTERLEAVED_COMPONENTS, &_info);
		cout << "Maximum feedback interleaved size: " << _info << endl << flush;
		glGetIntegerv(GL_MAX_TRANSFORM_FEEDBACK_SEPARATE_ATTRIBS, &_info);
		cout << "Maximum feedback separate size: " << _info << endl << flush;
		glGetIntegerv(GL_MAX_TRANSFORM_FEEDBACK_BUFFERS, &_info);
		cout << "Maximum feedback buffers size: " << _info << endl << flush;




		_gl_InitThreadData();

		// Start glut main loop to suspend the thread until the programs closes.
		glutMainLoop();
	}

}


/*
 * *************************************************************
 * 				FROM PROJECT BUILDING - METHOD B - Feedback
 * 				http://steps3d.narod.ru/tutorials/tf3-tutorial.html
 * *************************************************************
 */

int _glf_lasterror=0;
#define glfError(msg) if ((_glf_lasterror=glGetError())) cout<< "Error \"" << msg << "\", code: " << _glf_lasterror <<  endl << flush

void _glf_close(){cout << "glf closed normally.\n" ;}

GLuint glf_shaderID;
void _glf_relink(GLuint shaderID) {
	// Re link shader.
	GLint _linkedID;

	if (GLEW_ARB_get_program_binary)
		glProgramParameteri ( shaderID, GL_PROGRAM_BINARY_RETRIEVABLE_HINT, GL_TRUE );

	// Link the shader
	glLinkProgram(shaderID);
		glfError("shader_linking");

	glGetProgramiv(shaderID, GL_LINK_STATUS, &_linkedID);
	if(!_linkedID) cout << "Error occured while re-linking the shader.\n";
}

#define PSIZE 5000
float glf_data[2][PSIZE][3];

GLuint glf_vao[2], a_vbo[2], b_vbo[2];

void _glf_example(float x) {
	int i,j,k;
	for (i = 0;i<2;i++) {
		for (j =0 ;j<PSIZE ; j++) {
			for (k = 0;k<3;k++){
				glf_data[i][j][k] = x;
			}
		}
	}
}

enum LayoutLocation {
		lA = 0,
		lB = 1
	};

void _glf_init() {
	// Load and compile the shader.
	// All gpu math operation occur in the shader
	glf_shaderID = initShader("Shaders/pvs.glsl","Shaders/pfs.glsl");
	if (!glf_shaderID)
	{
		cout << "Error occurred while loading the shader..." << endl;
	}
	glfError("init shader");

	// Make this shader active to modify it.
	glUseProgram(glf_shaderID);

	// Now we are choosing which variables in the shader will
	// 		be used to give us feedback.
	const GLchar *shaderOutVars[] =
		{
				"outa",
				"outb",
		};
	glTransformFeedbackVaryings(glf_shaderID, 2 , shaderOutVars, GL_SEPARATE_ATTRIBS);
	glfError("init compile output");

	// Relink the shader:
	_glf_relink(glf_shaderID);
	glfError("init relink");

	// Assign vertex array (va) and vertex buffer (vb) objects.
	// We use them in pairs. Each time we write from one to the other.

	// Example data:
	_glf_example(2.0f);

	for (int i=0;i<2;i++) {
		// Generate and bind as active a new vao:
		glGenVertexArrays(1, &glf_vao[i]);
		glBindVertexArray(glf_vao[i]);
		glfError("init vao");

		// Generate, bind as active, and set data for each
		// buffer vertex.
		// Remember! this binds to the actvie vao.

		// A
		glGenBuffers(1, &a_vbo[i]);
		glBindBuffer(GL_ARRAY_BUFFER, a_vbo[i]);
		glBufferData(GL_ARRAY_BUFFER, sizeof(glf_data[0]) , glf_data[0], GL_DYNAMIC_DRAW);
		glVertexAttribPointer ( lA, 			// index in shader (layout)
								3, 			// number of values per vertex - 3 = vec3
								GL_FLOAT, 	// type (float)
								GL_FALSE,   // normalized?
								0, 			// stride (offset to next vertex data)
								(const GLvoid*) 0 ); //offset in bytes
		// Coonect it to the shader as vertex array:
		glEnableVertexAttribArray ( lA );
		glfError("init vbo a");

		// B
		glGenBuffers(1, &b_vbo[i]);
		glBindBuffer(GL_ARRAY_BUFFER, b_vbo[i]);
		glBufferData(GL_ARRAY_BUFFER, sizeof(glf_data[1]) , glf_data[1], GL_DYNAMIC_DRAW);
		glVertexAttribPointer ( lB, 			// index in shader (layout)
								3, 			// number of values per vertex - 3 = vec3
								GL_FLOAT, 	// type (float)
								GL_FALSE,   // normalized?
								0, 			// stride (offset to next vertex data)
								(const GLvoid*) 0 ); //offset in bytes
		// Coonect it to the shader as vertex array:
		glEnableVertexAttribArray ( lB );
		glfError("init vbo b");

		// Unbind vao - a good practice for oredr porpuses.
		glBindVertexArray(0 );
	}
}

int last_second = 0;
int frame_count = 0;

int currentPair = 0;
void _glf_draw() {
	// FPS Counter:
	if ((int)time(NULL) > last_second) {
		cout << "FPS: " << frame_count << endl;
		frame_count = 0;
		last_second = (int)time(NULL);
	}else{
		frame_count++;
	}


	// ****************************
	//		Feedback loop:
	// ****************************

	// Disable the rasterizer since we dont use it in the feedback loop:
	// (optional)
	glEnable (GL_RASTERIZER_DISCARD);
	glfError("draw init");

	currentPair ^= 1; // switch between 1 and 0.

	// Bind buffers to the output of the shader.
	glBindBufferBase(GL_TRANSFORM_FEEDBACK_BUFFER,lA,a_vbo[currentPair^1]);
	glBindBufferBase(GL_TRANSFORM_FEEDBACK_BUFFER,lB,b_vbo[currentPair^1]);
	glfError("draw bind output");

	// bind our shader:
	glUseProgram(glf_shaderID);

	// Set uniforms to active shader:
	glUniform1f ( glGetUniformLocation ( glf_shaderID, "mul" ), 2.0f);
	glfError("draw uniform");

	// Begin feedback:
	glBeginTransformFeedback(GL_POINTS); // Each vertex on its own.
	glfError("draw begin feedback");

	// Bind vao for the *Source* data
	glBindVertexArray(glf_vao[currentPair]);
	glfError("draw bind vao");

	glDrawArrays(GL_POINTS, 0 , PSIZE); // calculate to our feedback loop.
	glfError("draw array");

	// Unbind vao.
	glBindVertexArray(0);
	glfError("draw unbind vao");

	// End Feedback:
	glEndTransformFeedback();
	glfError("draw end feedback");

	// unbind our shader:
	glUseProgram(0);

	// ****************************
	//		Read back data:
	// ****************************

	// Bind vao of the *Target* data
	glBindVertexArray(glf_vao[currentPair^1]);
	glfError("draw bind vao for read");

	// Read Data from A:
	glBindBuffer(GL_ARRAY_BUFFER, a_vbo[currentPair^1]);

	void* ptr1 = glMapBuffer(GL_ARRAY_BUFFER, GL_READ_ONLY); //if (ptr1 != NULL) cout << "Part1 Sucess\n";
	glfError("draw read map 1");

	memcpy(glf_data[0],ptr1,sizeof(glf_data[0]));

	glUnmapBuffer(GL_ARRAY_BUFFER);
	glfError("draw read unmap 1");

	// Read Data from B:
	glBindBuffer(GL_ARRAY_BUFFER, b_vbo[currentPair^1]);


	void* ptr2 = glMapBuffer(GL_ARRAY_BUFFER, GL_READ_ONLY); //if (ptr2 != NULL) cout << "Part2 Sucess\n";
	glfError("draw read map 2");

	memcpy(glf_data[1],ptr2,sizeof(glf_data[1]));

	glUnmapBuffer(GL_ARRAY_BUFFER);
	glfError("draw read unmap 2");

	// Unbind vao.
	glBindVertexArray(0);
	glfError("draw unbind vao for read");

	// ****************************
	//		Refresh Screen:
	// ****************************
	glfError("draw black screen");

	glDisable (GL_RASTERIZER_DISCARD);

	// Clear color and Z (depth) buffer:
	glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	// Draw with debug color:
	glClearColor(0.74f,0.22f,0.21f,1.0f);

	// Swap the back and fron buffer:
	glutSwapBuffers();
}

void *_glf_Main(void* arg) {
	openglInitData *data = (openglInitData*)arg;

	// Start openGL context using glut library:
	glutInit(data->argc, data->argv);

	// We want our window to have color and depth buffers
	// with maximum of double percision.
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
	glutInitWindowSize(500,500);

	// We need openGL 3.3 context to support the feedback process
	// so we will ask for it:
	glutInitContextVersion(3,3);
	glutInitContextProfile(GLUT_CORE_PROFILE);

	// Set callback for the window we will create:
	glutDisplayFunc(&_glf_draw);
	glutIdleFunc(&_glf_draw);
	glutCloseFunc(&_glf_close);

	// Create the main window (must be done even if we won't draw on it)
	glutCreateWindow("OpenGL Particle filter with feedback");

	// openGL 3.3 on linux with glew is buggy. we need to allow
	//		experimental.
	glewExperimental = GL_TRUE;

	// Now we want to bind our windows with opengl. we do so with glew library
	// If we can't init it then somthing bad happened.
	if (glewInit() == GLEW_OK) {
		// As we said glew is buggy and this should give error 1280 but ignore it.
		glfError("glew_init_ignore");

		// Prepare the gpu for feedback process:
		_glf_init();

		// Start the loop to handlw windows events
		// 		and also hang the thread as long the window is open.
		glutMainLoop();
	}else{
		cout << "Error occured while gettin opengl 3.3 context." << endl;
	}


}
