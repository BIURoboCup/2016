/*
 * OpenGL_Utility.cpp
 *
 *  Created on: Jul 15, 2015
 *      Author: darwini5
 */


#include "gl_pf.hpp"

//#include "opencv2/core/opengl_interop.hpp"
// OpenGL Includes:

//#include <GL/glext.h>



#include <iostream>
#include <fstream>
#include <string>
using namespace std;


#include <stdio.h>
#include <time.h>


/*
 * *************************************************************
 * 				FROM WEBER COURSE - SEMSTER A (CG)
 * *************************************************************
 */

//Macro to make code more readable
#define BUFFER_OFFSET(offset)   ((GLvoid*) (offset))

struct Shader
{
	std::string filename;
	GLenum      type;
	std::string source;
};

std::string readShaderSource(const std::string& shaderFile)
{
	std::ifstream ifile(shaderFile.c_str());
	std::string filetext;

	while(ifile.good())
	{
		std::string line;
		std::getline(ifile, line);
		filetext.append(line + "\n");
	}
	ifile.close();
	return filetext;
}

//create a GLSL program object from vertex and fragment shader files
GLuint initShader(std::string vertexShaderFileName, std::string fragmentShaderFileName)
{
	const int shadersCount = 2;

	Shader shaders[shadersCount] =
	{
		{vertexShaderFileName, GL_VERTEX_SHADER, std::string()},
		{fragmentShaderFileName, GL_FRAGMENT_SHADER, std::string()}
	};

	GLuint program = glCreateProgram();

	for ( int i = 0; i < shadersCount; ++i ) {
		Shader& s = shaders[i];
		s.source = readShaderSource( s.filename );
		if (shaders[i].source.empty())
		{
			std::cout << "Failed to read " << s.filename << std::endl;
			return 0;
		}

		GLuint shader = glCreateShader( s.type );
		const GLchar* strings[1];
		strings[0] = s.source.c_str();
		glShaderSource(shader, 1, strings, NULL);

		glCompileShader( shader );

		GLint  compiled;
		glGetShaderiv( shader, GL_COMPILE_STATUS, &compiled );
		if ( !compiled ) {
			std::cout << s.filename << " failed to compile:" << std::endl;
			GLint  logSize = 0;
			glGetShaderiv(shader, GL_INFO_LOG_LENGTH, &logSize);
			char* logMsg = new char[logSize];
			glGetShaderInfoLog(shader, logSize, NULL, logMsg);
			std::cout << logMsg << std::endl;
			delete [] logMsg;
			return 0;
		}

		glAttachShader(program, shader);
	}

	/* link  and error check */
	glLinkProgram(program);

	GLint  linked;
	glGetProgramiv( program, GL_LINK_STATUS, &linked );
	if ( !linked ) {
		std::cout << "Shader program failed to link" << std::endl;
		GLint  logSize;
		glGetProgramiv( program, GL_INFO_LOG_LENGTH, &logSize);
		char* logMsg = new char[logSize];
		glGetProgramInfoLog( program, logSize, NULL, logMsg );
		std::cout << logMsg << std::endl;
		delete [] logMsg;

		return 0;
		//exit( EXIT_FAILURE );
	}

	/* use program object */
	glUseProgram(program);

	return program;
}

/*
 * *************************************************************
 * 				FROM PROJECT BUILDING - METHOD B - Feedback
 * 				http://steps3d.narod.ru/tutorials/tf3-tutorial.html
 * 				also from book :
 * 					Computer Graphics- From Pixels To Programmable Graphics Hardware
 * *************************************************************
 */

int _glf_lasterror=0;
#define glfError(msg) if ((_glf_lasterror=glGetError())) cout<< "Error \"" << msg << "\", code: " << _glf_lasterror <<  endl << flush

void _glf_close(){
	cout << "glf closed normally." << endl << flush ;
}

GLuint glf_shaderID;
void _glf_relink(GLuint shaderID) {
	// Re link shader.
	GLint _linkedID;

	if (GLEW_ARB_get_program_binary)
		glProgramParameteri ( shaderID, GL_PROGRAM_BINARY_RETRIEVABLE_HINT, GL_TRUE );

	// Link the shader
	glLinkProgram(shaderID);
		glfError("shader_linking");

	glGetProgramiv(shaderID, GL_LINK_STATUS, &_linkedID);
	if(!_linkedID) cout << "Error occured while re-linking the shader.\n";
}

#define PSIZE 5000
float glf_data[2][PSIZE][3];

GLuint glf_vao[2], a_vbo[2], b_vbo[2];

void _glf_example(float x) {
	int i,j,k;
	for (i = 0;i<2;i++) {
		for (j =0 ;j<PSIZE ; j++) {
			for (k = 0;k<3;k++){
				glf_data[i][j][k] = x;
			}
		}
	}
}

enum LayoutLocation {
		lA = 0,
		lB = 1
	};

void _glf_init() {
	// Load and compile the shader.
	// All gpu math operation occur in the shader
	glf_shaderID = initShader("Shaders/pvs.glsl","Shaders/pfs.glsl");
	if (!glf_shaderID)
	{
		cout << "Error occurred while loading the shader..." << endl;
	}
	glfError("init shader");

	// Make this shader active to modify it.
	glUseProgram(glf_shaderID);

	// Now we are choosing which variables in the shader will
	// 		be used to give us feedback.
	const GLchar *shaderOutVars[] =
		{
				"outa",
				"outb",
		};
	glTransformFeedbackVaryings(glf_shaderID, 2 , shaderOutVars, GL_SEPARATE_ATTRIBS);
	glfError("init compile output");

	// Relink the shader:
	_glf_relink(glf_shaderID);
	glfError("init relink");

	// Assign vertex array (va) and vertex buffer (vb) objects.
	// We use them in pairs. Each time we write from one to the other.

	// Example data:
	_glf_example(2.0f);

	for (int i=0;i<2;i++) {
		// Generate and bind as active a new vao:
		glGenVertexArrays(1, &glf_vao[i]);
		glBindVertexArray(glf_vao[i]);
		glfError("init vao");

		// Generate, bind as active, and set data for each
		// buffer vertex.
		// Remember! this binds to the actvie vao.

		// A
		glGenBuffers(1, &a_vbo[i]);
		glBindBuffer(GL_ARRAY_BUFFER, a_vbo[i]);
		glBufferData(GL_ARRAY_BUFFER, sizeof(glf_data[0]) , glf_data[0], GL_DYNAMIC_DRAW);
		glVertexAttribPointer ( lA, 			// index in shader (layout)
								3, 			// number of values per vertex - 3 = vec3
								GL_FLOAT, 	// type (float)
								GL_FALSE,   // normalized?
								0, 			// stride (offset to next vertex data)
								(const GLvoid*) 0 ); //offset in bytes
		// Coonect it to the shader as vertex array:
		glEnableVertexAttribArray ( lA );
		glfError("init vbo a");

		// B
		glGenBuffers(1, &b_vbo[i]);
		glBindBuffer(GL_ARRAY_BUFFER, b_vbo[i]);
		glBufferData(GL_ARRAY_BUFFER, sizeof(glf_data[1]) , glf_data[1], GL_DYNAMIC_DRAW);
		glVertexAttribPointer ( lB, 			// index in shader (layout)
								3, 			// number of values per vertex - 3 = vec3
								GL_FLOAT, 	// type (float)
								GL_FALSE,   // normalized?
								0, 			// stride (offset to next vertex data)
								(const GLvoid*) 0 ); //offset in bytes
		// Coonect it to the shader as vertex array:
		glEnableVertexAttribArray ( lB );
		glfError("init vbo b");

		// Unbind vao - a good practice for oredr porpuses.
		glBindVertexArray(0 );
	}
}

int last_second = 0;
int frame_count = 0;

int currentPair = 0;
void _glf_draw() {
	// FPS Counter:
	if ((int)time(NULL) > last_second) {
		cout << "FPS: " << frame_count << endl;
		frame_count = 0;
		last_second = (int)time(NULL);
	}else{
		frame_count++;
	}


	// ****************************
	//		Feedback loop:
	// ****************************

	// Disable the rasterizer since we dont use it in the feedback loop:
	// (optional)
	glEnable (GL_RASTERIZER_DISCARD);
	glfError("draw init");

	currentPair ^= 1; // switch between 1 and 0.

	// Bind buffers to the output of the shader.
	glBindBufferBase(GL_TRANSFORM_FEEDBACK_BUFFER,lA,a_vbo[currentPair^1]);
	glBindBufferBase(GL_TRANSFORM_FEEDBACK_BUFFER,lB,b_vbo[currentPair^1]);
	glfError("draw bind output");

	// bind our shader:
	glUseProgram(glf_shaderID);

	// Set uniforms to active shader:
	glUniform1f ( glGetUniformLocation ( glf_shaderID, "mul" ), 2.0f);
	glfError("draw uniform");

	// Begin feedback:
	glBeginTransformFeedback(GL_POINTS); // Each vertex on its own.
	glfError("draw begin feedback");

	// Bind vao for the *Source* data
	glBindVertexArray(glf_vao[currentPair]);
	glfError("draw bind vao");

	glDrawArrays(GL_POINTS, 0 , PSIZE); // calculate to our feedback loop.
	glfError("draw array");

	// Unbind vao.
	glBindVertexArray(0);
	glfError("draw unbind vao");

	// End Feedback:
	glEndTransformFeedback();
	glfError("draw end feedback");

	// unbind our shader:
	glUseProgram(0);

	// ****************************
	//		Read back data:
	// ****************************

	// Bind vao of the *Target* data
	glBindVertexArray(glf_vao[currentPair^1]);
	glfError("draw bind vao for read");

	// Read Data from A:
	glBindBuffer(GL_ARRAY_BUFFER, a_vbo[currentPair^1]);

	void* ptr1 = glMapBuffer(GL_ARRAY_BUFFER, GL_READ_ONLY); //if (ptr1 != NULL) cout << "Part1 Sucess\n";
	glfError("draw read map 1");

	memcpy(glf_data[0],ptr1,sizeof(glf_data[0]));

	glUnmapBuffer(GL_ARRAY_BUFFER);
	glfError("draw read unmap 1");

	// Read Data from B:
	glBindBuffer(GL_ARRAY_BUFFER, b_vbo[currentPair^1]);


	void* ptr2 = glMapBuffer(GL_ARRAY_BUFFER, GL_READ_ONLY); //if (ptr2 != NULL) cout << "Part2 Sucess\n";
	glfError("draw read map 2");

	memcpy(glf_data[1],ptr2,sizeof(glf_data[1]));

	glUnmapBuffer(GL_ARRAY_BUFFER);
	glfError("draw read unmap 2");

	// Unbind vao.
	glBindVertexArray(0);
	glfError("draw unbind vao for read");

	// ****************************
	//		Refresh Screen:
	// ****************************
	glfError("draw black screen");

	glDisable (GL_RASTERIZER_DISCARD);

	// Clear color and Z (depth) buffer:
	glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	// Draw with debug color:
	glClearColor(0.74f,0.22f,0.21f,1.0f);

	// Swap the back and fron buffer:
	glutSwapBuffers();
}

void *_glf_Main(void* arg) {
	openglInitData *data = (openglInitData*)arg;

	// Start openGL context using glut library:
	glutInit(data->argc, data->argv);

	// We want our window to have color and depth buffers
	// with maximum of double percision.
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
	glutInitWindowSize(500,500);

	// We need openGL 3.3 context to support the feedback process
	// so we will ask for it:
	glutInitContextVersion(3,3);
	glutInitContextProfile(GLUT_CORE_PROFILE);

	// Set callback for the window we will create:
	glutDisplayFunc(&_glf_draw);
	glutIdleFunc(&_glf_draw);
	glutCloseFunc(&_glf_close);

	// Create the main window (must be done even if we won't draw on it)
	glutCreateWindow("OpenGL Particle filter with feedback");

	// openGL 3.3 on linux with glew is buggy. we need to allow
	//		experimental.
	glewExperimental = GL_TRUE;

	// Now we want to bind our windows with opengl. we do so with glew library
	// If we can't init it then something bad happened.
	if (glewInit() == GLEW_OK) {
		// As we said glew is buggy and this should give error 1280 but ignore it.
		glfError("glew_init_ignore");

		// Print info about opengl context that concern us:
		int _info;


		cout << "GL Version  " << glGetString(GL_VERSION) << endl;
		cout << "GL Shader Version: " << glGetString(GL_SHADING_LANGUAGE_VERSION) << endl << flush;
		cout << "GL Vendor: " << glGetString(GL_VENDOR) << endl << flush;
		cout << "GL Renderer: " << glGetString(GL_RENDERER) << endl << endl << flush;

		// Info for Method A
		glGetIntegerv(GL_MAX_TEXTURE_IMAGE_UNITS, &_info);
		cout << "Maximum textures unit to be bound at once: " << _info << endl << flush;
		glGetIntegerv(GL_MAX_COMBINED_TEXTURE_IMAGE_UNITS, &_info);
		cout << "Maximum textures unit to be bound at once (all programs combined): " << _info << endl << flush;
		glGetIntegerv(GL_MAX_TEXTURE_SIZE, &_info);
		cout << "Maximum textures size: " << _info << endl << flush;

		// Info for Method B
		// Feedback info:
		glGetIntegerv(GL_MAX_TRANSFORM_FEEDBACK_INTERLEAVED_COMPONENTS, &_info);
		cout << "Maximum feedback interleaved variables count: " << _info << endl << flush;
		glGetIntegerv(GL_MAX_TRANSFORM_FEEDBACK_SEPARATE_ATTRIBS, &_info);
		cout << "Maximum feedback separate variables count: " << _info << endl << flush;
		glGetIntegerv(GL_MAX_TRANSFORM_FEEDBACK_BUFFERS, &_info);
		cout << "Maximum feedback buffers: " << _info << endl << flush;

		// Prepare the gpu for feedback process:
		_glf_init();

		// Start the loop to handle windows events
		// 		and also hang the thread as long the window is open.
		glutMainLoop();
	}else{
		cout << "Error occured while gettin opengl 3.3 context." << endl;
	}


}
