#ifndef GL_TOOLS
#define GL_TOOLS

#include "gl.hpp"

typedef struct {
	int* argc;
	char** argv;
} openglInitData;

// Tool for loading shader from text file.
GLuint initShader(std::string vertexShaderFileName, std::string fragmentShaderFileName);

// For time benchmarking:
#define time unsigned long long
// Cycles since the cpu is up:
static __inline__ time rdtsc(void)
{
    unsigned long long int x;
    __asm__ volatile (".byte 0x0f, 0x31" : "=A" (x));
    return x;
}

// Main particle filter thread:
void *_gl_MainThread(void* arg);



#endif
