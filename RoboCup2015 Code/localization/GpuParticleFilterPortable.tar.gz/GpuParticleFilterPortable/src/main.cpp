#include <iostream>
#include <stdio.h>

// Manage threads and signals:
#include <pthread.h>
#include <signal.h>


// OpenCV Includes:
#include "opencv2/core/core.hpp"
#include "opencv2/highgui/highgui.hpp"

#include "gl.hpp"
#include "OpenGL_Utility.hpp"

using namespace std;
using namespace cv;
//using namespace cv::cuda;

struct DrawData
{
    ogl::Arrays arr;
    ogl::Texture2D tex;
    ogl::Buffer indices;
};




int aa = 0;
void on_opengl(void* param)
{
	cout << "CV Shader Version: " << glGetString(GL_SHADING_LANGUAGE_VERSION) << endl << flush;
    glLoadIdentity();

    glTranslated(0.0, 0.0, -1.0);

    aa=(aa+1)%360;
    glRotatef( aa, 1, 0, 0 );
    glRotatef( aa , 0, 1, 0 );
    glRotatef( 0, 0, 0, 1 );

    static const int coords[6][4][3] = {
        { { +1, -1, -1 }, { -1, -1, -1 }, { -1, +1, -1 }, { +1, +1, -1 } },
        { { +1, +1, -1 }, { -1, +1, -1 }, { -1, +1, +1 }, { +1, +1, +1 } },
        { { +1, -1, +1 }, { +1, -1, -1 }, { +1, +1, -1 }, { +1, +1, +1 } },
        { { -1, -1, -1 }, { -1, -1, +1 }, { -1, +1, +1 }, { -1, +1, -1 } },
        { { +1, -1, +1 }, { -1, -1, +1 }, { -1, -1, -1 }, { +1, -1, -1 } },
        { { -1, -1, +1 }, { +1, -1, +1 }, { +1, +1, +1 }, { -1, +1, +1 } }
    };

    for (int i = 0; i < 6; ++i) {
        glColor3ub( i*20, 100+i*10, i*42 );
        glBegin(GL_QUADS);
        for (int j = 0; j < 4; ++j) {
            glVertex3d(0.2 * coords[i][j][0], 0.2 * coords[i][j][1], 0.2 * coords[i][j][2]);
        }
        glEnd();
    }
}

void *opencv_win(void* arg) {

			/*
		  setOpenGlDrawCallback("ME",&on_opengl);
		  updateWindow("ME");
*/



}

void old_glew() {
	// from week 1-2
	/*
	GLuint vbo = 0;
	  glGenBuffers (1, &vbo);
	  glBindBuffer (GL_ARRAY_BUFFER, vbo);
	  glBufferData (GL_ARRAY_BUFFER,  sizeof (points), points, GL_STATIC_DRAW);

	  // Verterx arttibute object, to pass data as an array, each vertex will get the corrosponding index.
	  // In this  case, we make at layer '0' with 3 floats to represent the XYZ.
	  //GLuint vao = 0;
	  glGenVertexArrays (1, &vao);
	  glBindVertexArray (vao);
	  glEnableVertexAttribArray (0);

	  // The arrtibute in layer 0 will be the vbo we defined just defined.
	  glBindBuffer (GL_ARRAY_BUFFER, vbo);
	  glVertexAttribPointer (0, 3, GL_FLOAT, GL_FALSE, 0, NULL);


	  cout << "GL Version  " << glGetString(GL_VERSION) << endl;
	  cout << "GL Shader Version: " << glGetString(GL_SHADING_LANGUAGE_VERSION) << endl << flush;
	  cout << "GL Vendor: " << glGetString(GL_VENDOR) << endl << flush;
	  cout << "GL Renderer: " << glGetString(GL_RENDERER) << endl << endl << flush;

	  if(!initShader("Shaders/pvs.glsl","Shaders/pfs.glsl")) {
		  cout << "Error occoured while loading the shader..." << endl;
		  return 0;
	  }

	  	  // Callbacks from opengl:
		  glutDisplayFunc(&draw);
		  glutIdleFunc(&draw);

		  glutCloseFunc(&glClosing);

		  glutMainLoop();
	  }else{
		  cout << "Error occoured!!" << endl;
	  }
	  */
}

void opencv_opengl_code_example() {
	/*


    string filename;
    if (argc < 2)
    {
        cout << "Usage: " << argv[0] << " image" << endl;
        filename = "lena.jpg";
    }
    else
        filename = argv[1];

    Mat img = imread(filename);

    if (img.empty())
    {
        cerr << "Can't open image " << filename << endl;
        return -1;
    }

    //namedWindow("OpenGL", WINDOW_OPENGL);
    namedWindow("ME");
    resizeWindow("OpenGL", win_width, win_height);

    Mat_<Vec2f> vertex(1, 4);
    vertex << Vec2f(-1, 1), Vec2f(-1, -1), Vec2f(1, -1), Vec2f(1, 1);

    Mat_<Vec2f> texCoords(1, 4);
    texCoords << Vec2f(0, 0), Vec2f(0, 1), Vec2f(1, 1), Vec2f(1, 0);

    Mat_<int> indices(1, 6);
    indices << 0, 1, 2, 2, 3, 0;

    DrawData data;

    data.arr.setVertexArray(vertex);
    data.arr.setTexCoordArray(texCoords);
    data.indices.copyFrom(indices);
    data.tex.copyFrom(img);

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(45.0, (double)win_width / win_height, 0.1, 100.0);

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    gluLookAt(0, 0, 3, 0, 0, 0, 0, 1, 0);

    glEnable(GL_TEXTURE_2D);
    data.tex.bind();

    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexEnvi(GL_TEXTURE_2D, GL_TEXTURE_ENV_MODE, GL_REPLACE);

    glDisable(GL_CULL_FACE);

    setOpenGlDrawCallback("OpenGL", draw, &data);

    cout << glGetString(GL_SHADING_LANGUAGE_VERSION) << endl << flush;

    for (;;)
    {
        updateWindow("OpenGL");
        int key = waitKey(40);
        if ((key & 0xff) == 27)
            break;
    }

    setOpenGlDrawCallback("OpenGL", 0, 0);
    destroyAllWindows();

    return 0;
    */

}



int main(int argc, char* argv[])
{
	int error=0;
	pthread_t t_opengl;
	openglInitData _data = {&argc, argv};
	if((error=pthread_create(&t_opengl,NULL , _gl_MainThread , &_data)))
	{
		cout << "cant create opengl thread! Error code: " << error << endl;
		return 0;
	}


	cv::namedWindow("ME",WINDOW_NORMAL);
	Mat img = imread("lena.jpg");
	imshow("ME",img);



	// Glut run in a different thread so we need somthing
	// to prevent closing the main thread.
	char q=' ';
	while( q != 'q') {
			q = waitKey(30);
	}

  return 0;

}
