#include <iostream>
#include <stdio.h>

// Manage threads and signals:
#include <pthread.h>
#include <signal.h>


// OpenCV Includes:
#include "opencv2/core/core.hpp"
#include "opencv2/highgui/highgui.hpp"

#include "gl.hpp"
#include "gl_pf.hpp"

#include "POIdata.hpp"

using namespace std;
using namespace cv;
//using namespace cv::cuda;

struct DrawData
{
    ogl::Arrays arr;
    ogl::Texture2D tex;
    ogl::Buffer indices;
};

int main(int argc, char* argv[])
{

	int error=0;
	pthread_t t_opengl;
	openglInitData _data = {&argc, argv};
	//if((error=pthread_create(&t_opengl,NULL , _gl_MainThread , &_data)))
	if((error=pthread_create(&t_opengl,NULL , _glf_Main , &_data)))
	{
		cout << "cant create opengl thread! Error code: " << error << endl;
		return 0;
	}


	// to Prove that normal opencv works:
	cv::namedWindow("ME",WINDOW_NORMAL);
	Mat img = imread("lena.jpg");
	imshow("ME",img);

	// Glut run in a different thread so we need somthing
	// to prevent closing the main thread.
	char q=' ';
	while( q != 'q') {
			q = waitKey(30);
	}

  return 0;

}
