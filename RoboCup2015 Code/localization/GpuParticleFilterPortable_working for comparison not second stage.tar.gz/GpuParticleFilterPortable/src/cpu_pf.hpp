#ifndef _CPU_PF
#define _CPU_PF

#include <cstdlib>
//#include <stdio.h>

#include "../glm/glm.hpp"
#include "../glm/fwd.hpp"
//#include "timer.hpp"

void _cpu_pf_init_test();
void _cpu_pf_main();
void _cpu_bench();

//#define CPU_PSIZE 5000

#endif
