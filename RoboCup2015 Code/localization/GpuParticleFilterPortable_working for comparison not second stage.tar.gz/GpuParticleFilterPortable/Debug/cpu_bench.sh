#!/bin/bash
for i in 1 10 100 200 500 700 1000 1200 1700 2200 2700 3000 3500 3700 4000 4096 8000 10000 50000
do

echo "N=$i"

g++ -I/usr/local/include -I/usr/local/include/opencv -O0 -g3 -Wall -c -fmessage-length=0 -MMD -MP -MF"src/cpu_pf.d" -MT"src/cpu_pf.d" -o "src/cpu_pf.o" "../src/cpu_pf.cpp" -D CPU_PSIZE=$i

g++ -I/usr/local/include -I/usr/local/include/opencv -O0 -g3 -Wall -c -fmessage-length=0 -MMD -MP -MF"src/main.d" -MT"src/main.d" -o "src/main.o" "../src/main.cpp"

g++  -o "cpuGpuParticleFilterPortable$i"  ./src/POIdata.o ./src/cpu_pf.o ./src/gl_pf.o ./src/main.o   -lopencv_core -lpthread -lopencv_imgproc -lopencv_highgui -lGLEW -lglut -lopencv_ml -lopencv_video -lopencv_features2d -lopencv_calib3d -lopencv_objdetect -lopencv_contrib -lopencv_legacy -lopencv_flann -lGL -lGLU

./cpuGpuParticleFilterPortable$i > cpu_out_$i.txt

 done
