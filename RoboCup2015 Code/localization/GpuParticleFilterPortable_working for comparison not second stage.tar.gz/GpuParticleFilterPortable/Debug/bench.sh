#!/bin/bash
#   4096 8000 10000
for i in 50000
do

echo "N=$i"

echo off

make all 
g++ -I/usr/local/include -I/usr/local/include/opencv -O0 -g3 -Wall -c -fmessage-length=0 -MMD -MP -MF"src/gl_pf.d" -MT"src/gl_pf.d" -o "src/gl_pf.o" "../src/gl_pf.cpp" -D PSIZE=$i

g++  -o "GpuParticleFilterPortable$i"  ./src/POIdata.o ./src/gl_pf.o ./src/main.o   -lopencv_core -lpthread -lopencv_imgproc -lopencv_highgui -lGLEW -lglut -lopencv_ml -lopencv_video -lopencv_features2d -lopencv_calib3d -lopencv_objdetect -lopencv_contrib -lopencv_legacy -lopencv_flann -lGL -lGLU

intel_gpu_top -o "gpu_$i.txt" -e "./GpuParticleFilterPortable$i > out_$i.txt"

echo on

done
